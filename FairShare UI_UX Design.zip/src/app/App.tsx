import { useState } from "react";
import {
  LayoutDashboard,
  Users,
  Plus,
  Sparkles,
  TrendingDown,
  TrendingUp,
  ArrowRight,
  X,
  Check,
  ChevronDown,
  Receipt,
  Utensils,
  Car,
  Home,
  Plane,
  ShoppingCart,
} from "lucide-react";

// ─── Types ───────────────────────────────────────────────────────────────────

type SplitType = "equal" | "exact" | "percent";

interface User {
  id: number;
  name: string;
  initials: string;
  color: string;
}

interface Balance {
  from: User;
  to: User;
  amount: number;
}

interface Activity {
  id: number;
  description: string;
  payer: User;
  amount: number;
  date: string;
  icon: React.ReactNode;
  participants: User[];
}

// ─── Seed Data ────────────────────────────────────────────────────────────────

const USERS: User[] = [
  { id: 1, name: "Alice Chen", initials: "AC", color: "#6366F1" },
  { id: 2, name: "Bob Patel", initials: "BP", color: "#10B981" },
  { id: 3, name: "Clara Kim", initials: "CK", color: "#F59E0B" },
  { id: 4, name: "David Torres", initials: "DT", color: "#14B8A6" },
  { id: 5, name: "Esha Gupta", initials: "EG", color: "#EC4899" },
];

const CURRENT_USER = USERS[0];

const INITIAL_BALANCES: Balance[] = [
  { from: USERS[1], to: USERS[0], amount: 142.5 },
  { from: USERS[2], to: USERS[0], amount: 87.0 },
  { from: USERS[0], to: USERS[3], amount: 55.0 },
  { from: USERS[4], to: USERS[1], amount: 30.25 },
  { from: USERS[3], to: USERS[2], amount: 200.0 },
];

const INITIAL_ACTIVITY: Activity[] = [
  {
    id: 1,
    description: "Dinner at Nobu",
    payer: USERS[0],
    amount: 320.0,
    date: "Jul 1",
    icon: <Utensils size={14} />,
    participants: [USERS[0], USERS[1], USERS[2]],
  },
  {
    id: 2,
    description: "Uber to Airport",
    payer: USERS[1],
    amount: 68.5,
    date: "Jun 29",
    icon: <Car size={14} />,
    participants: [USERS[1], USERS[3]],
  },
  {
    id: 3,
    description: "Airbnb – Lisbon",
    payer: USERS[3],
    amount: 1100.0,
    date: "Jun 25",
    icon: <Plane size={14} />,
    participants: USERS.slice(0, 4),
  },
  {
    id: 4,
    description: "Weekly Groceries",
    payer: USERS[2],
    amount: 145.8,
    date: "Jun 22",
    icon: <ShoppingCart size={14} />,
    participants: [USERS[0], USERS[2], USERS[4]],
  },
  {
    id: 5,
    description: "Rent – June",
    payer: USERS[0],
    amount: 2400.0,
    date: "Jun 1",
    icon: <Home size={14} />,
    participants: [USERS[0], USERS[1]],
  },
];

// ─── Helpers ─────────────────────────────────────────────────────────────────

const fmt = (n: number) =>
  n.toLocaleString("en-US", { style: "currency", currency: "USD" });

function Avatar({ user, size = 8 }: { user: User; size?: number }) {
  const dim = `h-${size} w-${size}`;
  return (
    <div
      className={`${dim} rounded-full flex items-center justify-center text-white font-semibold text-xs flex-shrink-0`}
      style={{ backgroundColor: user.color }}
    >
      {user.initials}
    </div>
  );
}

// ─── Glass Card ───────────────────────────────────────────────────────────────

function GlassCard({
  children,
  className = "",
}: {
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <div
      className={`rounded-2xl border border-white/5 backdrop-blur-sm ${className}`}
      style={{ background: "rgba(30, 41, 59, 0.7)" }}
    >
      {children}
    </div>
  );
}

// ─── Summary Cards ────────────────────────────────────────────────────────────

function SummaryCards({
  balances,
  currentUser,
}: {
  balances: Balance[];
  currentUser: User;
}) {
  const totalOwed = balances
    .filter((b) => b.from.id === currentUser.id)
    .reduce((s, b) => s + b.amount, 0);
  const totalOwedToYou = balances
    .filter((b) => b.to.id === currentUser.id)
    .reduce((s, b) => s + b.amount, 0);
  const net = totalOwedToYou - totalOwed;

  return (
    <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
      {/* Net balance */}
      <GlassCard className="p-5 sm:col-span-1 relative overflow-hidden">
        <div
          className="absolute inset-0 opacity-10 rounded-2xl"
          style={{
            background:
              net >= 0
                ? "linear-gradient(135deg, #10B981, transparent)"
                : "linear-gradient(135deg, #EF4444, transparent)",
          }}
        />
        <p className="text-xs font-medium tracking-widest uppercase text-slate-400 mb-2">
          Net Balance
        </p>
        <p
          className="text-3xl font-bold font-['Outfit']"
          style={{ color: net >= 0 ? "#10B981" : "#EF4444" }}
        >
          {net >= 0 ? "+" : ""}
          {fmt(net)}
        </p>
        <p className="text-xs text-slate-500 mt-1">
          {net >= 0 ? "You are owed overall" : "You owe overall"}
        </p>
      </GlassCard>

      {/* Owed to you */}
      <GlassCard className="p-5 relative overflow-hidden">
        <div className="absolute inset-0 opacity-10 rounded-2xl" style={{ background: "linear-gradient(135deg, #10B981, transparent)" }} />
        <div className="flex items-center gap-2 mb-2">
          <TrendingUp size={14} className="text-emerald-400" />
          <p className="text-xs font-medium tracking-widest uppercase text-slate-400">
            Owed to You
          </p>
        </div>
        <p className="text-2xl font-bold font-['Outfit'] text-emerald-400">
          {fmt(totalOwedToYou)}
        </p>
        <p className="text-xs text-slate-500 mt-1">
          from {balances.filter((b) => b.to.id === currentUser.id).length} people
        </p>
      </GlassCard>

      {/* You owe */}
      <GlassCard className="p-5 relative overflow-hidden">
        <div className="absolute inset-0 opacity-10 rounded-2xl" style={{ background: "linear-gradient(135deg, #EF4444, transparent)" }} />
        <div className="flex items-center gap-2 mb-2">
          <TrendingDown size={14} className="text-red-400" />
          <p className="text-xs font-medium tracking-widest uppercase text-slate-400">
            You Owe
          </p>
        </div>
        <p className="text-2xl font-bold font-['Outfit'] text-red-400">
          {fmt(totalOwed)}
        </p>
        <p className="text-xs text-slate-500 mt-1">
          to {balances.filter((b) => b.from.id === currentUser.id).length} people
        </p>
      </GlassCard>
    </div>
  );
}

// ─── Balance Row ──────────────────────────────────────────────────────────────

function BalanceRow({ balance, currentUser }: { balance: Balance; currentUser: User }) {
  const isYouOwe = balance.from.id === currentUser.id;
  const isOwedToYou = balance.to.id === currentUser.id;

  return (
    <div className="flex items-center justify-between py-3 border-b border-white/5 last:border-0 group hover:bg-white/[0.02] -mx-4 px-4 rounded-lg transition-colors">
      <div className="flex items-center gap-3">
        <Avatar user={balance.from} size={8} />
        <ArrowRight size={14} className="text-slate-600" />
        <Avatar user={balance.to} size={8} />
        <div className="ml-1">
          <p className="text-sm text-slate-200">
            <span className="font-semibold">
              {balance.from.id === currentUser.id ? "You" : balance.from.name.split(" ")[0]}
            </span>
            <span className="text-slate-500 mx-1">owes</span>
            <span className="font-semibold">
              {balance.to.id === currentUser.id ? "you" : balance.to.name.split(" ")[0]}
            </span>
          </p>
        </div>
      </div>
      <span
        className="text-sm font-bold font-['JetBrains_Mono']"
        style={{
          color: isOwedToYou ? "#10B981" : isYouOwe ? "#EF4444" : "#94A3B8",
        }}
      >
        {fmt(balance.amount)}
      </span>
    </div>
  );
}

// ─── Dashboard ────────────────────────────────────────────────────────────────

function Dashboard({
  balances,
  setBalances,
  activity,
  currentUser,
  onAddExpense,
}: {
  balances: Balance[];
  setBalances: (b: Balance[]) => void;
  activity: Activity[];
  currentUser: User;
  onAddExpense: () => void;
}) {
  const [simplified, setSimplified] = useState(false);

  function simplifyDebts() {
    // Greedy simplification: compute net balance per user then settle
    const net: Record<number, number> = {};
    balances.forEach((b) => {
      net[b.from.id] = (net[b.from.id] || 0) - b.amount;
      net[b.to.id] = (net[b.to.id] || 0) + b.amount;
    });

    const creditors: { user: User; amount: number }[] = [];
    const debtors: { user: User; amount: number }[] = [];
    USERS.forEach((u) => {
      const n = net[u.id] || 0;
      if (n > 0.01) creditors.push({ user: u, amount: n });
      else if (n < -0.01) debtors.push({ user: u, amount: -n });
    });

    const result: Balance[] = [];
    let ci = 0;
    let di = 0;
    while (ci < creditors.length && di < debtors.length) {
      const settle = Math.min(creditors[ci].amount, debtors[di].amount);
      result.push({ from: debtors[di].user, to: creditors[ci].user, amount: +settle.toFixed(2) });
      creditors[ci].amount -= settle;
      debtors[di].amount -= settle;
      if (creditors[ci].amount < 0.01) ci++;
      if (debtors[di].amount < 0.01) di++;
    }

    setBalances(result);
    setSimplified(true);
  }

  return (
    <div className="space-y-6">
      <SummaryCards balances={balances} currentUser={currentUser} />

      <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
        {/* Balances panel */}
        <GlassCard className="lg:col-span-3 p-5">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-base font-semibold text-slate-100 font-['Outfit']">
                Balances
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                {simplified ? "Optimized — minimum transactions" : `${balances.length} active debts`}
              </p>
            </div>
            <button
              onClick={simplifyDebts}
              disabled={simplified}
              className="flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all duration-200"
              style={{
                background: simplified
                  ? "rgba(16, 185, 129, 0.1)"
                  : "linear-gradient(135deg, #6366F1, #818CF8)",
                color: simplified ? "#10B981" : "#fff",
                boxShadow: simplified ? "none" : "0 0 20px rgba(99,102,241,0.3)",
              }}
            >
              {simplified ? (
                <>
                  <Check size={12} /> Simplified
                </>
              ) : (
                <>
                  <Sparkles size={12} /> Simplify Debts
                </>
              )}
            </button>
          </div>
          <div>
            {balances.length === 0 ? (
              <p className="text-center text-slate-500 py-8 text-sm">
                All settled up! 🎉
              </p>
            ) : (
              balances.map((b, i) => (
                <BalanceRow key={i} balance={b} currentUser={currentUser} />
              ))
            )}
          </div>
        </GlassCard>

        {/* Recent Activity */}
        <GlassCard className="lg:col-span-2 p-5">
          <h2 className="text-base font-semibold text-slate-100 font-['Outfit'] mb-4">
            Recent Activity
          </h2>
          <div className="space-y-1">
            {activity.map((item) => (
              <div
                key={item.id}
                className="flex items-start gap-3 py-2.5 border-b border-white/5 last:border-0"
              >
                <div
                  className="h-7 w-7 rounded-lg flex items-center justify-center flex-shrink-0 mt-0.5"
                  style={{ background: "rgba(99,102,241,0.15)", color: "#818CF8" }}
                >
                  {item.icon}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm text-slate-200 font-medium truncate">
                    {item.description}
                  </p>
                  <p className="text-xs text-slate-500 mt-0.5">
                    {item.payer.name.split(" ")[0]} paid · {item.date}
                  </p>
                </div>
                <span className="text-xs font-bold font-['JetBrains_Mono'] text-slate-300 flex-shrink-0">
                  {fmt(item.amount)}
                </span>
              </div>
            ))}
          </div>
        </GlassCard>
      </div>

      {/* FAB */}
      <button
        onClick={onAddExpense}
        className="fixed bottom-8 right-8 flex items-center gap-2 px-5 py-3 rounded-full text-sm font-semibold text-white transition-all duration-200 hover:scale-105 active:scale-95"
        style={{
          background: "linear-gradient(135deg, #6366F1, #818CF8)",
          boxShadow: "0 0 30px rgba(99,102,241,0.4), 0 4px 16px rgba(0,0,0,0.3)",
        }}
      >
        <Plus size={16} />
        Add Expense
      </button>
    </div>
  );
}

// ─── Add Expense Modal ────────────────────────────────────────────────────────

function AddExpenseModal({
  users,
  currentUser,
  onClose,
  onSave,
}: {
  users: User[];
  currentUser: User;
  onClose: () => void;
  onSave: (activity: Activity) => void;
}) {
  const [description, setDescription] = useState("");
  const [amount, setAmount] = useState("");
  const [payerId, setPayerId] = useState(currentUser.id);
  const [splitType, setSplitType] = useState<SplitType>("equal");
  const [selected, setSelected] = useState<Set<number>>(
    new Set(users.map((u) => u.id))
  );
  const [exactAmounts, setExactAmounts] = useState<Record<number, string>>({});
  const [percentAmounts, setPercentAmounts] = useState<Record<number, string>>({});
  const [payerOpen, setPayerOpen] = useState(false);

  const total = parseFloat(amount) || 0;
  const selectedUsers = users.filter((u) => selected.has(u.id));
  const equalShare = selectedUsers.length > 0 ? total / selectedUsers.length : 0;

  const exactSum = Object.values(exactAmounts).reduce(
    (s, v) => s + (parseFloat(v) || 0),
    0
  );
  const percentSum = Object.values(percentAmounts).reduce(
    (s, v) => s + (parseFloat(v) || 0),
    0
  );

  const exactValid = Math.abs(exactSum - total) < 0.01;
  const percentValid = Math.abs(percentSum - 100) < 0.01;
  const canSave =
    description.trim() &&
    total > 0 &&
    selectedUsers.length > 0 &&
    (splitType === "equal" ||
      (splitType === "exact" && exactValid) ||
      (splitType === "percent" && percentValid));

  function toggleUser(id: number) {
    setSelected((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  }

  function handleSave() {
    const payer = users.find((u) => u.id === payerId)!;
    onSave({
      id: Date.now(),
      description,
      payer,
      amount: total,
      date: "Jul 2",
      icon: <Receipt size={14} />,
      participants: selectedUsers,
    });
    onClose();
  }

  const splitTabs: { key: SplitType; label: string }[] = [
    { key: "equal", label: "Equal" },
    { key: "exact", label: "Exact $" },
    { key: "percent", label: "Percent %" },
  ];

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4"
      style={{ background: "rgba(0,0,0,0.7)", backdropFilter: "blur(8px)" }}
      onClick={(e) => e.target === e.currentTarget && onClose()}
    >
      <div
        className="w-full max-w-md rounded-2xl border border-white/10 shadow-2xl overflow-hidden"
        style={{ background: "#111827" }}
      >
        {/* Header */}
        <div
          className="flex items-center justify-between px-6 py-4 border-b border-white/5"
          style={{ background: "rgba(99,102,241,0.08)" }}
        >
          <h2 className="text-lg font-bold font-['Outfit'] text-white">
            New Expense
          </h2>
          <button
            onClick={onClose}
            className="h-8 w-8 rounded-lg flex items-center justify-center text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
          >
            <X size={16} />
          </button>
        </div>

        <div className="p-6 space-y-5 max-h-[80vh] overflow-y-auto">
          {/* Description */}
          <div>
            <label className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1.5 block">
              Description
            </label>
            <input
              type="text"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="e.g. Dinner at Luigi's"
              className="w-full px-3 py-2.5 rounded-xl text-sm text-slate-100 placeholder-slate-600 outline-none transition-all"
              style={{
                background: "rgba(30,41,59,0.8)",
                border: "1px solid rgba(99,102,241,0.2)",
              }}
            />
          </div>

          {/* Amount + Payer */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1.5 block">
                Amount ($)
              </label>
              <input
                type="number"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder="0.00"
                min="0"
                step="0.01"
                className="w-full px-3 py-2.5 rounded-xl text-sm text-slate-100 placeholder-slate-600 outline-none font-['JetBrains_Mono'] transition-all"
                style={{
                  background: "rgba(30,41,59,0.8)",
                  border: "1px solid rgba(99,102,241,0.2)",
                }}
              />
            </div>
            <div className="relative">
              <label className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1.5 block">
                Paid by
              </label>
              <button
                onClick={() => setPayerOpen(!payerOpen)}
                className="w-full px-3 py-2.5 rounded-xl text-sm text-slate-100 flex items-center justify-between outline-none transition-all"
                style={{
                  background: "rgba(30,41,59,0.8)",
                  border: "1px solid rgba(99,102,241,0.2)",
                }}
              >
                <span>{users.find((u) => u.id === payerId)?.name.split(" ")[0]}</span>
                <ChevronDown size={14} className="text-slate-500" />
              </button>
              {payerOpen && (
                <div
                  className="absolute top-full mt-1 w-full rounded-xl border border-white/10 overflow-hidden z-10"
                  style={{ background: "#1E293B" }}
                >
                  {users.map((u) => (
                    <button
                      key={u.id}
                      onClick={() => { setPayerId(u.id); setPayerOpen(false); }}
                      className="w-full flex items-center gap-2 px-3 py-2 text-sm text-slate-200 hover:bg-white/10 transition-colors"
                    >
                      <Avatar user={u} size={6} />
                      {u.name.split(" ")[0]}
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Participants */}
          <div>
            <label className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2 block">
              Split Between
            </label>
            <div className="flex flex-wrap gap-2">
              {users.map((u) => {
                const active = selected.has(u.id);
                return (
                  <button
                    key={u.id}
                    onClick={() => toggleUser(u.id)}
                    className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-full text-xs font-medium transition-all duration-150"
                    style={{
                      background: active
                        ? `${u.color}22`
                        : "rgba(30,41,59,0.6)",
                      border: `1px solid ${active ? u.color + "55" : "rgba(255,255,255,0.06)"}`,
                      color: active ? u.color : "#64748B",
                    }}
                  >
                    <div
                      className="h-4 w-4 rounded-full flex items-center justify-center text-white text-[8px] font-bold"
                      style={{ backgroundColor: active ? u.color : "#334155" }}
                    >
                      {u.initials[0]}
                    </div>
                    {u.name.split(" ")[0]}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Split Type Tabs */}
          <div>
            <div
              className="flex rounded-xl p-1 mb-4"
              style={{ background: "rgba(15,23,42,0.8)" }}
            >
              {splitTabs.map((tab) => (
                <button
                  key={tab.key}
                  onClick={() => setSplitType(tab.key)}
                  className="flex-1 py-1.5 rounded-lg text-xs font-semibold transition-all duration-200"
                  style={{
                    background:
                      splitType === tab.key
                        ? "linear-gradient(135deg, #6366F1, #818CF8)"
                        : "transparent",
                    color: splitType === tab.key ? "#fff" : "#64748B",
                    boxShadow:
                      splitType === tab.key
                        ? "0 2px 8px rgba(99,102,241,0.3)"
                        : "none",
                  }}
                >
                  {tab.label}
                </button>
              ))}
            </div>

            {/* Equal split preview */}
            {splitType === "equal" && (
              <div className="space-y-1.5">
                {selectedUsers.map((u) => (
                  <div
                    key={u.id}
                    className="flex items-center justify-between px-3 py-2 rounded-xl"
                    style={{ background: "rgba(30,41,59,0.5)" }}
                  >
                    <div className="flex items-center gap-2">
                      <Avatar user={u} size={6} />
                      <span className="text-sm text-slate-300">{u.name.split(" ")[0]}</span>
                    </div>
                    <span className="text-sm font-bold font-['JetBrains_Mono'] text-slate-300">
                      {fmt(equalShare)}
                    </span>
                  </div>
                ))}
              </div>
            )}

            {/* Exact amounts */}
            {splitType === "exact" && (
              <div className="space-y-2">
                {selectedUsers.map((u) => (
                  <div key={u.id} className="flex items-center gap-3">
                    <div className="flex items-center gap-2 flex-1">
                      <Avatar user={u} size={6} />
                      <span className="text-sm text-slate-300">{u.name.split(" ")[0]}</span>
                    </div>
                    <input
                      type="number"
                      placeholder="0.00"
                      value={exactAmounts[u.id] || ""}
                      onChange={(e) =>
                        setExactAmounts((prev) => ({
                          ...prev,
                          [u.id]: e.target.value,
                        }))
                      }
                      className="w-28 px-3 py-2 rounded-xl text-sm text-right text-slate-100 placeholder-slate-600 outline-none font-['JetBrains_Mono']"
                      style={{
                        background: "rgba(30,41,59,0.8)",
                        border: `1px solid ${exactValid || exactSum === 0 ? "rgba(99,102,241,0.2)" : "rgba(239,68,68,0.4)"}`,
                      }}
                    />
                  </div>
                ))}
                <div className="flex justify-between pt-1 text-xs">
                  <span className="text-slate-500">Total allocated</span>
                  <span
                    className="font-bold font-['JetBrains_Mono']"
                    style={{ color: exactValid ? "#10B981" : exactSum > 0 ? "#EF4444" : "#64748B" }}
                  >
                    {fmt(exactSum)} / {fmt(total)}
                  </span>
                </div>
              </div>
            )}

            {/* Percent amounts */}
            {splitType === "percent" && (
              <div className="space-y-2">
                {selectedUsers.map((u) => (
                  <div key={u.id} className="flex items-center gap-3">
                    <div className="flex items-center gap-2 flex-1">
                      <Avatar user={u} size={6} />
                      <span className="text-sm text-slate-300">{u.name.split(" ")[0]}</span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <input
                        type="number"
                        placeholder="0"
                        value={percentAmounts[u.id] || ""}
                        onChange={(e) =>
                          setPercentAmounts((prev) => ({
                            ...prev,
                            [u.id]: e.target.value,
                          }))
                        }
                        className="w-20 px-3 py-2 rounded-xl text-sm text-right text-slate-100 placeholder-slate-600 outline-none font-['JetBrains_Mono']"
                        style={{
                          background: "rgba(30,41,59,0.8)",
                          border: `1px solid ${percentValid || percentSum === 0 ? "rgba(99,102,241,0.2)" : "rgba(239,68,68,0.4)"}`,
                        }}
                      />
                      <span className="text-slate-500 text-sm">%</span>
                    </div>
                  </div>
                ))}
                <div className="flex justify-between pt-1 text-xs">
                  <span className="text-slate-500">Total</span>
                  <span
                    className="font-bold font-['JetBrains_Mono']"
                    style={{ color: percentValid ? "#10B981" : percentSum > 0 ? "#EF4444" : "#64748B" }}
                  >
                    {percentSum.toFixed(1)}% / 100%
                  </span>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t border-white/5 flex gap-3">
          <button
            onClick={onClose}
            className="flex-1 py-2.5 rounded-xl text-sm font-semibold text-slate-400 hover:text-slate-200 hover:bg-white/5 transition-all"
          >
            Cancel
          </button>
          <button
            onClick={handleSave}
            disabled={!canSave}
            className="flex-1 py-2.5 rounded-xl text-sm font-semibold text-white transition-all duration-200 hover:scale-[1.02] active:scale-[0.98]"
            style={{
              background: canSave
                ? "linear-gradient(135deg, #6366F1, #818CF8)"
                : "rgba(99,102,241,0.2)",
              color: canSave ? "#fff" : "#6366F1",
              boxShadow: canSave ? "0 0 20px rgba(99,102,241,0.3)" : "none",
            }}
          >
            Save Expense
          </button>
        </div>
      </div>
    </div>
  );
}

// ─── Friends Screen ───────────────────────────────────────────────────────────

function FriendsScreen({
  users,
  onAddUser,
  balances,
  currentUser,
}: {
  users: User[];
  onAddUser: (name: string) => void;
  balances: Balance[];
  currentUser: User;
}) {
  const [name, setName] = useState("");

  function handleAdd() {
    if (!name.trim()) return;
    onAddUser(name.trim());
    setName("");
  }

  function netForUser(user: User) {
    let net = 0;
    balances.forEach((b) => {
      if (b.to.id === user.id && b.from.id === currentUser.id) net -= b.amount;
      if (b.from.id === user.id && b.to.id === currentUser.id) net += b.amount;
    });
    return net;
  }

  return (
    <div className="space-y-6 max-w-2xl">
      {/* Add user form */}
      <GlassCard className="p-5">
        <h2 className="text-base font-semibold text-slate-100 font-['Outfit'] mb-4">
          Add a Friend
        </h2>
        <div className="flex gap-3">
          <input
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && handleAdd()}
            placeholder="e.g. Jordan Lee"
            className="flex-1 px-3 py-2.5 rounded-xl text-sm text-slate-100 placeholder-slate-600 outline-none transition-all"
            style={{
              background: "rgba(30,41,59,0.8)",
              border: "1px solid rgba(99,102,241,0.2)",
            }}
          />
          <button
            onClick={handleAdd}
            disabled={!name.trim()}
            className="px-4 py-2.5 rounded-xl text-sm font-semibold text-white flex items-center gap-2 transition-all duration-200 hover:scale-105 active:scale-95"
            style={{
              background: name.trim()
                ? "linear-gradient(135deg, #6366F1, #818CF8)"
                : "rgba(99,102,241,0.2)",
              color: name.trim() ? "#fff" : "#6366F1",
              boxShadow: name.trim() ? "0 0 16px rgba(99,102,241,0.3)" : "none",
            }}
          >
            <Plus size={14} />
            Add Friend
          </button>
        </div>
      </GlassCard>

      {/* User list */}
      <GlassCard className="p-5">
        <h2 className="text-base font-semibold text-slate-100 font-['Outfit'] mb-1">
          Group Members
        </h2>
        <p className="text-xs text-slate-500 mb-4">{users.length} people in your group</p>
        <div className="space-y-1">
          {users.map((user) => {
            const net = netForUser(user);
            const isCurrentUser = user.id === currentUser.id;
            return (
              <div
                key={user.id}
                className="flex items-center justify-between py-3 border-b border-white/5 last:border-0 hover:bg-white/[0.02] -mx-4 px-4 rounded-lg transition-colors"
              >
                <div className="flex items-center gap-3">
                  <Avatar user={user} size={10} />
                  <div>
                    <p className="text-sm font-semibold text-slate-100">
                      {user.name}
                      {isCurrentUser && (
                        <span className="ml-2 text-xs px-1.5 py-0.5 rounded-full font-normal"
                          style={{ background: "rgba(99,102,241,0.2)", color: "#818CF8" }}>
                          you
                        </span>
                      )}
                    </p>
                    <p className="text-xs text-slate-500 font-['JetBrains_Mono']">
                      {user.initials}
                    </p>
                  </div>
                </div>
                {!isCurrentUser && (
                  <div className="text-right">
                    {net === 0 ? (
                      <span className="text-xs text-slate-500">Settled up</span>
                    ) : (
                      <>
                        <p
                          className="text-sm font-bold font-['JetBrains_Mono']"
                          style={{ color: net > 0 ? "#10B981" : "#EF4444" }}
                        >
                          {net > 0 ? "+" : ""}{fmt(Math.abs(net))}
                        </p>
                        <p className="text-xs text-slate-500">
                          {net > 0 ? "owes you" : "you owe"}
                        </p>
                      </>
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </GlassCard>
    </div>
  );
}

// ─── Nav ─────────────────────────────────────────────────────────────────────

type Screen = "dashboard" | "friends";

const NAV_ITEMS: { id: Screen; label: string; icon: React.ReactNode }[] = [
  { id: "dashboard", label: "Dashboard", icon: <LayoutDashboard size={16} /> },
  { id: "friends", label: "Friends", icon: <Users size={16} /> },
];

// ─── App Root ─────────────────────────────────────────────────────────────────

export default function App() {
  const [screen, setScreen] = useState<Screen>("dashboard");
  const [showModal, setShowModal] = useState(false);
  const [users, setUsers] = useState<User[]>(USERS);
  const [balances, setBalances] = useState<Balance[]>(INITIAL_BALANCES);
  const [activity, setActivity] = useState<Activity[]>(INITIAL_ACTIVITY);

  const COLORS = ["#6366F1", "#10B981", "#F59E0B", "#14B8A6", "#EC4899", "#F97316", "#8B5CF6"];

  function handleAddUser(name: string) {
    const initials = name
      .split(" ")
      .map((w) => w[0])
      .join("")
      .toUpperCase()
      .slice(0, 2);
    const newUser: User = {
      id: Date.now(),
      name,
      initials,
      color: COLORS[users.length % COLORS.length],
    };
    setUsers((prev) => [...prev, newUser]);
  }

  function handleSaveExpense(item: Activity) {
    setActivity((prev) => [item, ...prev]);
  }

  return (
    <div
      className="min-h-screen font-['Inter']"
      style={{
        background: "linear-gradient(135deg, #0F172A 0%, #0B1120 50%, #0F172A 100%)",
      }}
    >
      {/* Ambient glow */}
      <div
        className="fixed top-0 left-1/2 -translate-x-1/2 w-[600px] h-[300px] rounded-full opacity-10 pointer-events-none"
        style={{
          background: "radial-gradient(ellipse, #6366F1, transparent 70%)",
          filter: "blur(40px)",
        }}
      />

      {/* Sidebar */}
      <div className="flex min-h-screen">
        <aside
          className="w-60 flex-shrink-0 hidden md:flex flex-col border-r border-white/[0.06] sticky top-0 h-screen"
          style={{ background: "rgba(11,17,32,0.9)" }}
        >
          {/* Logo */}
          <div className="px-6 py-6 border-b border-white/[0.06]">
            <div className="flex items-center gap-2.5">
              <div
                className="h-8 w-8 rounded-xl flex items-center justify-center"
                style={{ background: "linear-gradient(135deg, #6366F1, #818CF8)" }}
              >
                <Receipt size={16} className="text-white" />
              </div>
              <span className="text-lg font-bold font-['Outfit'] text-white tracking-tight">
                FairShare
              </span>
            </div>
          </div>

          {/* User */}
          <div className="px-4 py-4 border-b border-white/[0.06]">
            <div className="flex items-center gap-3 px-2 py-2 rounded-xl" style={{ background: "rgba(99,102,241,0.08)" }}>
              <Avatar user={CURRENT_USER} size={8} />
              <div>
                <p className="text-sm font-semibold text-slate-100">{CURRENT_USER.name.split(" ")[0]}</p>
                <p className="text-xs text-slate-500">Active</p>
              </div>
            </div>
          </div>

          {/* Nav */}
          <nav className="p-3 flex-1">
            {NAV_ITEMS.map((item) => {
              const active = screen === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => setScreen(item.id)}
                  className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all duration-150 mb-1"
                  style={{
                    background: active ? "rgba(99,102,241,0.15)" : "transparent",
                    color: active ? "#818CF8" : "#64748B",
                    borderLeft: active ? "2px solid #6366F1" : "2px solid transparent",
                  }}
                >
                  {item.icon}
                  {item.label}
                </button>
              );
            })}
          </nav>

          {/* Add expense sidebar CTA */}
          <div className="p-4 border-t border-white/[0.06]">
            <button
              onClick={() => setShowModal(true)}
              className="w-full flex items-center justify-center gap-2 py-2.5 rounded-xl text-sm font-semibold text-white transition-all duration-200 hover:scale-[1.02] active:scale-[0.98]"
              style={{
                background: "linear-gradient(135deg, #6366F1, #818CF8)",
                boxShadow: "0 0 20px rgba(99,102,241,0.3)",
              }}
            >
              <Plus size={15} />
              Add Expense
            </button>
          </div>
        </aside>

        {/* Main */}
        <main className="flex-1 min-w-0">
          {/* Top bar */}
          <header
            className="px-6 md:px-8 py-5 border-b border-white/[0.06] flex items-center justify-between sticky top-0 z-20"
            style={{ background: "rgba(15,23,42,0.9)", backdropFilter: "blur(12px)" }}
          >
            <div>
              <h1 className="text-xl font-bold font-['Outfit'] text-white">
                {screen === "dashboard" ? "Dashboard" : "Friends"}
              </h1>
              <p className="text-xs text-slate-500 mt-0.5">
                {screen === "dashboard"
                  ? "Your group finances at a glance"
                  : "Manage your group members"}
              </p>
            </div>
            {/* Mobile nav */}
            <div className="flex gap-2 md:hidden">
              {NAV_ITEMS.map((item) => (
                <button
                  key={item.id}
                  onClick={() => setScreen(item.id)}
                  className="p-2 rounded-lg transition-colors"
                  style={{
                    background: screen === item.id ? "rgba(99,102,241,0.2)" : "transparent",
                    color: screen === item.id ? "#818CF8" : "#64748B",
                  }}
                >
                  {item.icon}
                </button>
              ))}
            </div>
          </header>

          <div className="px-6 md:px-8 py-8">
            {screen === "dashboard" && (
              <Dashboard
                balances={balances}
                setBalances={setBalances}
                activity={activity}
                currentUser={CURRENT_USER}
                onAddExpense={() => setShowModal(true)}
              />
            )}
            {screen === "friends" && (
              <FriendsScreen
                users={users}
                onAddUser={handleAddUser}
                balances={balances}
                currentUser={CURRENT_USER}
              />
            )}
          </div>
        </main>
      </div>

      {showModal && (
        <AddExpenseModal
          users={users}
          currentUser={CURRENT_USER}
          onClose={() => setShowModal(false)}
          onSave={handleSaveExpense}
        />
      )}
    </div>
  );
}
